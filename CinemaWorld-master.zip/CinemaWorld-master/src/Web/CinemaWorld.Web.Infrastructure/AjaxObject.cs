﻿namespace CinemaWorld.Web.Infrastructure
{
    public class AjaxObject
    {
        public bool Success { get; set; }

        public string Message { get; set; }

        public string Action { get; set; }
    }
}
