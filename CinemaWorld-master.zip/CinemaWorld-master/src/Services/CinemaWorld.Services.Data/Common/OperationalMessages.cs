﻿namespace CinemaWorld.Services.Data.Common
{
    public static class OperationalMessages
    {
        public const string SuccessfullyBookedMovieProjection = "Movie projection has been successfully booked!";
    }
}
