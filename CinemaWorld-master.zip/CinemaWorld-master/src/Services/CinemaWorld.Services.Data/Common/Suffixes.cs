﻿namespace CinemaWorld.Services.Data.Common
{
    public static class Suffixes
    {
        public const string WallpaperSuffix = "_Wallpaper";
        public const string NewsSuffix = "_NewsImage";
    }
}
