﻿namespace CinemaWorld.Services.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapFrom<T>
    {
    }
}
