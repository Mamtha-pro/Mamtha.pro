﻿namespace CinemaWorld.Data.Models
{
    using CinemaWorld.Data.Common.Models;

    public class Setting : BaseDeletableModel<int>
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}
