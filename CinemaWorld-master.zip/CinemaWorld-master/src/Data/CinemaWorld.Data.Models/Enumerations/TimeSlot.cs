﻿namespace CinemaWorld.Data.Models.Enumerations
{
    public enum TimeSlot
    {
        Morning = 1,
        Lunch = 2,
        Afternoon = 3,
        Еvening = 4,
    }
}
