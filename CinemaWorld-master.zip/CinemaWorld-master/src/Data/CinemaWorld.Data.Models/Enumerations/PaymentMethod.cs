﻿namespace CinemaWorld.Data.Models.Enumerations
{
    public enum PaymentMethod
    {
        Cash = 1,
        Card = 2,
    }
}
