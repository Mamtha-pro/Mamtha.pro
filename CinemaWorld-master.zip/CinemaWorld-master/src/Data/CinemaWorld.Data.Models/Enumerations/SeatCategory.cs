﻿namespace CinemaWorld.Data.Models.Enumerations
{
    public enum SeatCategory
    {
        Normal = 1,
        Wheelchair = 2,
    }
}
