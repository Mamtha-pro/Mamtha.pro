﻿namespace CinemaWorld.Data.Models.Enumerations
{
    public enum CinemaCategory
    {
        A = 1,
        B = 2,
        C = 3,
        D = 4,
        X = 5,
    }
}
