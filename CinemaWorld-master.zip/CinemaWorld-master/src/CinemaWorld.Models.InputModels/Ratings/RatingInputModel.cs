﻿namespace CinemaWorld.Models.InputModels.Ratings
{
    using System;

    public class RatingInputModel
    {
        public int MovieId { get; set; }

        public int Rating { get; set; }
    }
}
