﻿namespace CinemaWorld.Models.ViewModels
{
    public class BookingErrorViewModel : ErrorViewModel
    {
        public string ErrorMessage { get; set; }
    }
}
