﻿namespace CinemaWorld.Models.ViewModels
{
    public class HttpErrorViewModel
    {
        public int StatusCode { get; set; }
    }
}
